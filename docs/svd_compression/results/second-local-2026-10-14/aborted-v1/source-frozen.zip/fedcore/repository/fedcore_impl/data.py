from fedcore.data.data import CompressionInputData
from typing import Union
from fedot.core.data.data import InputData
from fedot.core.data.multi_modal import MultiModalData
from fedot.core.optimisers.objective import DataSource


def build_holdout_producer(self, data: CompressionInputData):
    """
    Build trivial data producer for hold-out validation
    that always returns same data split. Equivalent to 1-fold validation.
    """

    def convert_compression_to_input(data):
        is_input_data = isinstance(data, InputData)
        if is_input_data:
            return data
        
        model = data.target if data.target is not None else getattr(data, 'model', None)
        converted = InputData(
            idx=[1],
            features=data,
            target=model,
            task=data.task,
            data_type=None,
            supplementary_data=data.supplementary_data,
        )
        return converted

    train_data, test_data = convert_compression_to_input(
        data
    ), convert_compression_to_input(data)
    train_data.supplementary_data.is_auto_preprocessed = True
    test_data.supplementary_data.is_auto_preprocessed = True
    
    def data_producer():
        """Returns iterable with single fold (train_data, test_data) for holdout validation"""
        return [(train_data, test_data)]
    
    return data_producer


def build_fedcore_dataproducer(
    self, data: Union[InputData, MultiModalData]
) -> DataSource:
    return self._build_holdout_producer(data)
