from random import choice
from typing import Sequence, Optional, Dict, Any

from golem.core.dag.graph import Graph
from golem.core.optimisers.adaptive.mab_agents.contextual_mab_agent import ContextualMultiArmedBanditAgent
from golem.core.optimisers.adaptive.mab_agents.mab_agent import MultiArmedBanditAgent
from golem.core.optimisers.adaptive.mab_agents.neural_contextual_mab_agent import NeuralContextualMultiArmedBanditAgent
from golem.core.optimisers.adaptive.operator_agent import RandomAgent
from golem.core.optimisers.genetic.gp_optimizer import EvoGraphOptimizer
from golem.core.optimisers.genetic.gp_params import GPAlgorithmParameters
from golem.core.optimisers.genetic.operators.operator import EvaluationOperator, PopulationT
from golem.core.optimisers.graph import OptGraph
from golem.core.optimisers.objective import Objective, ObjectiveFunction
from golem.core.optimisers.opt_history_objects.individual import Individual
from golem.core.optimisers.optimization_parameters import GraphRequirements
from golem.core.optimisers.optimizer import GraphGenerationParams
from golem.core.optimisers.populational_optimizer import _try_unfit_graph
from fedcore.interfaces.search_trace import SearchTrace, individual_record

from fedcore.interfaces.fedcore_dispatcher import FedcoreDispatcher
from fedcore.repository.constant_repository import (
    FEDCORE_MUTATION_STRATEGY,
    FEDCORE_GRAPH_VALIDATION,
)
from fedcore.repository.initializer_industrial_models import FedcoreModels


class FedcoreEvoOptimizer(EvoGraphOptimizer):
    def __init__(self,
                 objective: Objective,
                 initial_graphs: Sequence[OptGraph],
                 requirements: GraphRequirements,
                 graph_generation_params: GraphGenerationParams,
                 graph_optimizer_params: GPAlgorithmParameters,
                 optimisation_params: dict = {'mutation_agent': 'random',
                                              'mutation_strategy': 'params_mutation_strategy'}):
        graph_optimizer_params = self._init_industrial_optimizer_params(graph_optimizer_params, optimisation_params)
        super().__init__(objective, initial_graphs, requirements,
                         graph_generation_params, graph_optimizer_params)
        # self.operators.remove(self.crossover)
        self.search_trace = SearchTrace(optimisation_params.get('trace_path'))
        self.evaluated_population = []
        self.requirements = requirements
        self.initial_graphs = initial_graphs
        self.eval_dispatcher = FedcoreDispatcher(
            adapter=graph_generation_params.adapter,
            n_jobs=requirements.n_jobs,
            graph_cleanup_fn=_try_unfit_graph,
            delegate_evaluator=graph_generation_params.remote_evaluator)

    def _init_industrial_optimizer_params(self, graph_optimizer_params, optimisation_params):
        self.mutation_agent_dict = {'random': RandomAgent,
                                    'bandit': MultiArmedBanditAgent,
                                    'contextual_bandit': ContextualMultiArmedBanditAgent,
                                    'neural_bandit': NeuralContextualMultiArmedBanditAgent}
        # Min pop size to avoid getting stuck in local maximum during optimization.
        self.min_pop_size = 10
        # Min reproduce attempt for evolve and mutation stage.
        self.min_reproduce_attempt = 50
        # Max number of evaluations attempts to create graph for next pop
        self.graph_generation_attempts = 100
        graph_optimizer_params = self._exclude_resample_from_mutations(graph_optimizer_params)
        graph_optimizer_params.adaptive_mutation_type = self._set_optimisation_strategy(graph_optimizer_params,
                                                                                        optimisation_params)
        return graph_optimizer_params

    def _set_optimisation_strategy(self, graph_optimizer_params, optimisation_params):
        self.optimisation_mutation_probs = FEDCORE_MUTATION_STRATEGY[optimisation_params['mutation_strategy']]
        mutation_agent = self.mutation_agent_dict[optimisation_params['mutation_agent']]
        if optimisation_params['mutation_agent'].__contains__('random'):
            mutation_agent = mutation_agent(actions=graph_optimizer_params.mutation_types,
                                            probs=self.optimisation_mutation_probs)
        else:
            mutation_agent = mutation_agent(actions=graph_optimizer_params.mutation_types)
        return mutation_agent

    def _exclude_resample_from_mutations(self, graph_optimizer_params):
        for mutation in graph_optimizer_params.mutation_types:
            try:
                is_invalid = mutation.__name__.__contains__('resample')
            except Exception:
                is_invalid = mutation.name.__contains__('resample')
            if is_invalid:
                graph_optimizer_params.mutation_types.remove(mutation)
        return graph_optimizer_params

    def _initial_population(self, evaluator: EvaluationOperator):
        """ Initializes the initial population """
        # Adding of initial assumptions to history as zero generation
        pop_size = self.graph_optimizer_params.pop_size
        label = 'initial_assumptions'
        initial_individuals = [Individual(graph, metadata=self.requirements.static_individual_metadata)
                               for graph in self.initial_graphs]
        if len(initial_individuals) <= pop_size and pop_size != 1:  # in case we have only one init assumption
            # change strategy of init assumption creation. Set max probability to node change mutation
            self.mutation.agent._probs = FEDCORE_MUTATION_STRATEGY['initial_population_diversity_strategy']
            initial_individuals = self._extend_population(initial_individuals, pop_size)
            self.mutation.agent._probs = self.optimisation_mutation_probs
            label = 'extended_initial_assumptions'
        init_population = evaluator(initial_individuals)
        if init_population is None:
            self.log.error('Initial population evaluation returned None despite safety wrapper')
            self.log.error(f'Initial individuals count: {len(initial_individuals)}')
            raise ValueError('evaluator returned None - this indicates a critical error in evaluation system')
        elif not init_population:
            self.log.error('Initial population evaluation returned empty list - cannot proceed without individuals')
            self.log.error(f'Initial individuals count: {len(initial_individuals)}')
            self.log.error('This usually means all evaluations failed. Check logs above for evaluation errors.')
            raise ValueError('evaluator returned empty list - cannot initialize optimization without individuals. '
                           'All initial individuals failed evaluation. Check logs for details.')
        
        if init_population is None:
            self.log.error('CRITICAL: init_population is None right before _update_population')
            raise ValueError('init_population cannot be None')
        
        self._update_population(next_population=init_population, evaluator=evaluator, label=label)
        return init_population, evaluator

    def compare_dicts(self, dict1, dict2, path=None, differences=None):
        """
        Debug method
        TODO: delete when release
        """
        if differences is None:
            differences = []
        if path is None:
            path = []
        if not (isinstance(dict1, dict) and isinstance(dict2, dict)):
            differences.append('.'.join(path))
            return differences

        all_keys = set(dict1.keys()) | set(dict2.keys())

        for key in all_keys:
            current_path = path + [str(key)]
            if key not in dict1:
                differences.append('.'.join(current_path))
                continue
            if key not in dict2:
                differences.append('.'.join(current_path))
                continue

            value1 = dict1[key]
            value2 = dict2[key]
            if isinstance(value1, dict) and isinstance(value2, dict):
                self.compare_dicts(value1, value2, current_path, differences)
            elif value1 != value2:
                differences.append('.'.join(current_path))

        return differences

    def _extend_population(self, pop: PopulationT, target_pop_size: int, mutation_prob: list = None) -> PopulationT:
        verifier, new_population = self.graph_generation_params.verifier, list(pop)
        # redefine golem's individual verification rules excluding unnecessary checks
        verifier._rules = FEDCORE_GRAPH_VALIDATION
        if not pop or len(new_population) >= target_pop_size:
            return new_population
        pop_graphs = [ind.graph for ind in new_population]
        for _ in range(self.graph_generation_attempts):
            for _ in range(self.min_reproduce_attempt):
                random_ind = choice(pop)
                result = self.mutation(random_ind)
                # GOLEM returns [] when mutation fails, and some versions return
                # a population even for one parent. Verify only real individuals.
                candidates = [result] if isinstance(result, Individual) else result if isinstance(result, (list, tuple)) else ()
                added = False
                for candidate in candidates:
                    if not isinstance(candidate, Individual):
                        continue
                    if candidate.graph not in pop_graphs and verifier(candidate.graph):
                        new_population.append(candidate)
                        pop_graphs.append(candidate.graph)
                        added = True
                    if len(new_population) >= target_pop_size:
                        return new_population
                if added:
                    break
            if len(new_population) >= target_pop_size:
                break
        return new_population

    def _update_population(self,
                           next_population: PopulationT,
                           evaluator: EvaluationOperator = None,
                           label: Optional[str] = None,
                           metadata: Optional[Dict[str, Any]] = None):
        self.generations.append(next_population)
        if self.requirements.keep_history:
            self._log_to_history(next_population, label, metadata)
        self._iteration_callback(next_population, self)
        self.population = next_population
        self.search_trace.record('population', generation=self.current_generation_num,
                                 label=label,
                                 individuals=[individual_record(item) for item in next_population],
                                 archive=[individual_record(item) for item in self.generations.best_individuals])
        self.log.info(f'Generation num: {self.current_generation_num} size: {len(next_population)}')
        self.log.info(f'Best individuals: {str(self.generations)}')
        if self.generations.stagnation_iter_count > 0:
            self.log.info(f'no improvements for {self.generations.stagnation_iter_count} iterations')
            self.log.info(f'spent time: {round(self.timer.minutes_from_start, 1)} min')
        return next_population

    def _evolve_population(self,
                           population: PopulationT,
                           evaluator: EvaluationOperator) -> PopulationT:
        """ Method realizing full evolution cycle """
        individuals_to_select = self.regularization(population, evaluator)
        try: 
            new_population = self.reproducer.reproduce(individuals_to_select, evaluator)
        except Exception as x:
            self.log.warning(f'Exception during reproduction: {x}')
            new_population = None
        if new_population is None:
            new_population = population
        else:
            self.log.message(f'Successful reproduction')

        # Adaptive agent experience collection & learning
        # Must be called after reproduction (that collects the new experience)
        experience = self.mutation.agent_experience
        experience.collect_results(new_population)
        self.mutation.agent.partial_fit(experience)

        # Use some part of previous pop in the next pop
        new_population = self.inheritance(population, new_population)
        new_population = self.elitism(self.generations.best_individuals, new_population)
        return new_population, evaluator

    def get_structure_unique_population(self, population: PopulationT, evaluator: EvaluationOperator) -> PopulationT:
        """ Increases structurally uniqueness of population to prevent stagnation in optimization process.
        Returned population may be not entirely unique, if the size of unique population is lower than MIN_POP_SIZE. """
        unique_population_with_ids = {ind.graph.descriptive_id: ind for ind in population}
        unique_population = list(unique_population_with_ids.values())
        is_population_too_small = len(unique_population) <= self.min_pop_size
        # if size of unique population is too small, then extend it to MIN_POP_SIZE by repeating individuals
        if is_population_too_small:
            self.mutation.agent._probs = FEDCORE_MUTATION_STRATEGY['initial_population_diversity_strategy']
            unique_population = self._extend_population(pop=unique_population,
                                                        target_pop_size=self.min_pop_size)
            self.mutation.agent._probs = self.optimisation_mutation_probs
            population = evaluator(unique_population)
        return population, evaluator

    def _update_requirements(self, population, evaluator):
        # Defines adaptive changes to algorithm parameters like pop_size and operator probabilities
        if not self.generations.is_any_improved:
            self.graph_optimizer_params.mutation_prob, self.graph_optimizer_params.crossover_prob = \
                self._operators_prob.next(population)
            self.log.info(
                f'Next mutation proba: {self.graph_optimizer_params.mutation_prob}; '
                f'Next crossover proba: {self.graph_optimizer_params.crossover_prob}')
        self.graph_optimizer_params.pop_size = self._pop_size.next(population)
        self.requirements.max_depth = self._graph_depth.next()
        self.log.info(f'Next population size: {self.graph_optimizer_params.pop_size}; '
                      f''f'max graph depth: {self.requirements.max_depth}')

        # update requirements in operators
        for operator in self.operators:
            operator.update_requirements(self.graph_optimizer_params, self.requirements)
        return population, evaluator

    def _optimise_loop(self, population_to_eval, evaluator):
        opt_data = (population_to_eval, evaluator)
        opt_data = self._update_requirements(*opt_data)
        self.search_trace.record('requirements',
                                 mutation_probability=self.graph_optimizer_params.mutation_prob,
                                 crossover_probability=self.graph_optimizer_params.crossover_prob,
                                 population_size=self.graph_optimizer_params.pop_size,
                                 max_depth=self.requirements.max_depth)
        fitness_data = self._evolve_population(*opt_data)
        reg_data = self.get_structure_unique_population(*fitness_data)
        evaluated_population = self._update_population(*reg_data)
        return evaluated_population

    def optimise(self, objective: ObjectiveFunction) -> Sequence[Graph]:
        with self.timer, self._progressbar as pbar:
            evaluator = self.search_trace.evaluator(self.eval_dispatcher.dispatch(objective, self.timer))
            self.search_trace.record('configuration',
                                     mutation_probability=self.graph_optimizer_params.mutation_prob,
                                     crossover_probability=self.graph_optimizer_params.crossover_prob,
                                     selection=str(self.graph_optimizer_params.selection_types),
                                     objective_names=list(self.objective.metric_names),
                                     mutation_agent=type(self.mutation.agent).__name__,
                                     mutation_operators=[getattr(op, '__name__', str(op))
                                                         for op in self.graph_optimizer_params.mutation_types],
                                     crossover_operators=[str(op) for op in self.graph_optimizer_params.crossover_types],
                                     timeout_minutes=str(self.requirements.timeout),
                                     max_generations=self.requirements.num_of_generations)
            population_to_eval, evaluator = self._initial_population(evaluator)
            self.evaluated_population.append(population_to_eval)
            while not self.stop_optimization():
                population_to_eval = self._optimise_loop(population_to_eval=population_to_eval,
                                                        evaluator=evaluator)
                self.evaluated_population.append(population_to_eval)
                pbar.update()
            pbar.close()
        self._update_population(self.best_individuals, None, 'final_choices')
        self.search_trace.record('stopped', generations=self.current_generation_num,
                                 elapsed_minutes=self.timer.minutes_from_start,
                                 criterion='GOLEM stop_optimization: timeout/generation/stagnation criteria')
        best_models = [ind.graph for ind in self.best_individuals]
        return best_models
