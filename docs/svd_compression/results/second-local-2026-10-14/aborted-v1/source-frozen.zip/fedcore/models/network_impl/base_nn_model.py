from datetime import datetime
from enum import Enum
from functools import reduce, partial
from itertools import chain
from typing import Iterable, Optional, Any, Union, Callable, Sequence
from pymonad.maybe import Maybe
import numpy as np
import torch
import torch.nn.functional as F
from fedot.core.data.data import InputData
from fedot.core.operations.operation_parameters import OperationParameters
from fedot.core.repository.dataset_types import DataTypesEnum
from torch import Tensor
from tqdm import tqdm
import logging

from fedcore.api.utils.data import DataLoaderHandler
from fedcore.architecture.computational.devices import default_device
from fedcore.data.data import CompressionInputData, CompressionOutputData
from fedcore.repository.constant_repository import (
    StructureCriterions,
    TorchLossesConstant,
)

from fedcore.models.network_impl.utils.hooks import BaseHook
from fedcore.models.network_impl.utils.hooks_collection import HooksCollection
# from fedcore.models.network_impl.hooks_collection import HooksCollection
from fedcore.models.network_impl.utils.hooks import LOGGING_HOOKS, MODEL_LEARNING_HOOKS
from fedcore.models.network_impl.utils._base import BaseTrainer

BASE_REGRESSION_DTYPE = torch.float32


class BaseNeuralModel(torch.nn.Module, BaseTrainer):
    """Class responsible for NN model implementation.

    Attributes:
        self.num_features: int, the number of features.

    Example:
        Build a Fedot pipeline with a neural model node, fit it on
        :class:`~fedot.core.data.data.InputData`, and call ``predict``.
    """
    BASE_HOOKS : list[type['BaseHook']] = LOGGING_HOOKS + MODEL_LEARNING_HOOKS

    def __init__(self, model: Optional[torch.nn.Module] = None, params: dict = {}, additional_hooks: Sequence['BaseHook'] = None):
        torch.nn.Module.__init__(self)
        BaseTrainer.__init__(self, model=model, params=params)

        self.learning_params = self.params.get('custom_learning_params', {})
        self._init_null_object()
        self._init_empty_object()

        self.epochs = self.params.get("epochs", 1)
        self.batch_size = self.params.get("batch_size", 16)
        self.learning_rate = self.params.get("learning_rate", 0.001)

        self.model = model
        self._init_custom_criterions(self.params.get("custom_criterions", {})) # let it be dict[name : coef], let nodes add it to trainer
        self.criterion = self.__init_main_criterion()
        self.device = self.params.get('device', default_device())
        self.model_params = self.params.get('model_params', {})
        self._additional_hooks = additional_hooks or []
        self._clear_each = self.learning_params.get('clear_each', 10)

    @property
    def model_before(self):
        return self.model

    @property
    def model_after(self):
        return self.model

    def _init_custom_criterions(self, custom_criterions: dict):
        self.custom_criterions = dict()
        for name, coef in custom_criterions.items():
            if hasattr(StructureCriterions, name):
                criterion = StructureCriterions[name].value
            elif hasattr(TorchLossesConstant, name):
                criterion = TorchLossesConstant[name].value
            else:
                raise ValueError(f'Unknown type `{name}` of custom loss')
            self.history[f'train_{name}_loss'] = []
            self.history[f'val_{name}_loss'] = []
            self.custom_criterions[name] = (criterion(), coef)

    def _init_null_object(self):
        self.label_encoder = None
        self.is_regression_task = False
        self.target = None
        self.task_type = None
        self.checkpoint_folder = self.params.get('checkpoint_folder', None)
        self.batch_limit = self.learning_params.get('batch_limit', None)
        self.calib_batch_limit = self.learning_params.get('calib_batch_limit', None)
        self.batch_type = self.learning_params.get('batch_type', None)

    def _init_empty_object(self):
        self.history = {
            'train_loss': [],
            'val_loss': []
        }
        # add hooks
        self.hooks = HooksCollection()

    def __repr__(self):
        return self.__class__.__name__ + '\n' + repr(self.hooks)

    def _init_model(self):
        pass

    def _init_hooks(self):
        for hook_elem in chain(self.BASE_HOOKS, self._additional_hooks):
            # Pre-built hook instances (e.g. pruning agents) are linked as-is.
            if isinstance(hook_elem, BaseHook):
                if hasattr(hook_elem, "link_to_trainer"):
                    hook_elem.link_to_trainer(self)
                else:
                    hook_elem.hookable_trainer = self
                    hook_elem.params = self.params
                    hook_elem.model = self.model
                self.hooks.append(hook_elem)
                continue
            hook_type: type[BaseHook] = hook_elem
            if not hook_type.check_init(self.params):
                continue
            hook: BaseHook = hook_type(self)
            self.hooks.append(hook)

    def __init_main_criterion(self):
        key = self.params.get('criterion', None)
        if isinstance(key, str):
            return TorchLossesConstant[key].value()
        elif isinstance(key, Callable):
            return key
        else:
            return None

    def save_model(self, path: str):
        torch.save(self.model.state_dict(), path)

    def load_model(self, path: str):
        if self.model is None:
            self._init_model()
        try:  # path to state_dict
            self.model.load_state_dict(torch.load(path, weights_only=False))
        except Exception:  # path to model_impl
            self.model = torch.load(path, map_location=self.device)
        self.model.eval()


    def __substitute_device_quant(self):
        return
        if not getattr(self.model, '_is_quantized', False):
            self.device = default_device('cpu')
            self.model.to(self.device)
            logging.info('Quantized model inference supports CPU only')

    def fit(self, input_data: CompressionInputData, supplementary_data: dict = None, loader_type='train'):
        # define data for fit process
        self.custom_fit_process = supplementary_data is not None
        train_loader = input_data.train_dataloader
        val_loader = input_data.val_dataloader
        self.task_type = input_data.task.task_type
        # define model for fit process
        self.model = input_data.model if self.model is None else self.model
        self.optimised_model = self.model
        self.model.to(self.device)
        self._init_hooks()
        self._train_loop(
            train_loader=train_loader,
            val_loader=val_loader,
            loss_fn=self.criterion,
        )
        self._clear_cache()
        return self.model

    def _run_one_epoch(self, epoch, dataloader, loss_fn, optimizer):
        training_loss = 0.0
        self.model.train()
        for batch in tqdm(dataloader, desc='Batch #'):
            *inputs, targets = batch
            inputs = tuple(inputs_.to(self.device) for inputs_ in inputs if hasattr(inputs_, 'to'))
            targets = targets.to(self.device)
            output = self.model(*inputs)
            if self.task_type.name == 'regression' or self.task_type.name.__contains__('forecasting'):
                targets = targets.to(BASE_REGRESSION_DTYPE)
                output = output.to(BASE_REGRESSION_DTYPE)
            loss = self._compute_loss(loss_fn, output,
                                      targets.to(self.device), epoch=epoch)
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            training_loss += loss.item()
        avg_loss = training_loss / len(dataloader)
        self.history['train_loss'].append((epoch, avg_loss))  # changed to match epoch and loss

    def _train_loop(self, train_loader, val_loader, loss_fn):
        train_loader = DataLoaderHandler.check_convert(dataloader=train_loader,
                                                       mode=self.batch_type,
                                                       max_batches=self.batch_limit,
                                                       enumerate=False)
        for epoch in range(1, self.epochs + 1):
            for hook in self.hooks.start():
                hook(epoch=epoch, trainer_objects=self.trainer_objects,
                     learning_rate=self.learning_rate)
            self._run_one_epoch(epoch=epoch,
                                dataloader=train_loader,
                                loss_fn=loss_fn,
                                optimizer=self.optimizer)
            for hook in self.hooks.end():
                hook(epoch=epoch, val_loader=val_loader,
                     criterion=partial(self._compute_loss, criterion=loss_fn),
                     history=self.history)
        return self

    def predict(self, input_data: CompressionInputData, output_mode: str = "default"):
        """
        Method for feature generation for all series
        """
        self.__substitute_device_quant()
        return self._predict_model(input_data, output_mode)

    def predict_for_fit(self, input_data: CompressionInputData, output_mode: str = "default"):
        """
        Method for feature generation for all series
        """
        self.__substitute_device_quant()
        return self._predict_model(input_data, output_mode)

    @staticmethod
    def filter_hooks_by_params(params, hook_types) -> list:
        filtered_hooks = []
        for hook_type in hook_types:
            if not hook_type.check_init(params):
                continue
            filtered_hooks.append(hook_type)
        return filtered_hooks

    @torch.no_grad()
    def _predict_model(self, x_test: CompressionInputData, output_mode: str = 'default'):
        model = self.model if self.model is not None else x_test.model
        if model is None:
            raise ValueError('A model is required for prediction')
        model.to(self.device)
        modes = [(child, child.training) for child in model.modules()]
        prediction, targets = [], []
        dataloader = DataLoaderHandler.check_convert(x_test.val_dataloader,
            mode=self.batch_type, max_batches=self.calib_batch_limit)
        if self.task_type is None:
            self.task_type = x_test.task.task_type
        try:
            model.eval()
            for batch in dataloader:
                *inputs, target = batch
                inputs = tuple(value.to(self.device) for value in inputs)
                prediction.append(model(*inputs).detach().cpu())
                targets.append(torch.as_tensor(target).detach().cpu())
        finally:
            for child, training in modes:
                child.training = training
        if not prediction:
            raise ValueError('Evaluation source is empty')
        output = self._convert_predict(torch.cat(prediction), output_mode, x_test)
        output.target = torch.cat(targets)
        output.idx = np.arange(len(output.target))
        return output

    def _convert_predict(self, pred: Tensor, output_mode: str = "labels", input_data: Union[CompressionInputData, InputData] = None):
        assert isinstance(pred, torch.Tensor), "Prediction convertion failed, prediction is not a Tensor"
        have_encoder = all([self.label_encoder is not None, output_mode == "labels"])
        if self.task_type.name == 'regression':
            self.is_regression_task = True
        output_is_clf_labels = all(
            [not self.is_regression_task, output_mode == "labels"]
        )
        pred = Maybe.insert(pred). \
            then(
            lambda predict: predict.cpu().detach().numpy() if self.is_regression_task else F.softmax(predict, dim=1)). \
            then(
            lambda predict: torch.argmax(predict, dim=1).cpu().detach().numpy() if output_is_clf_labels else predict). \
            then(lambda predict: self.label_encoder.inverse_transform(predict) if have_encoder else predict). \
            maybe(None, lambda output: output)

        extracted_fields = self._extract_output_fields(input_data)

        checkpoint_info = self._register_model_checkpoint(
            model=self.model,
            stage='after'
        )

        predict = CompressionOutputData(
            features=extracted_fields['features'],
            task=self.task_type,
            predict=pred,
            num_classes=extracted_fields['num_classes'],
            train_dataloader=extracted_fields['train_dataloader'],
            val_dataloader=extracted_fields['val_dataloader'],
            data_type=DataTypesEnum.table,
            model=self.model,
            checkpoint_path=checkpoint_info['checkpoint_path'],
            model_id=checkpoint_info['model_id'],
            fedcore_id=checkpoint_info['fedcore_id'],
        )
        return predict

    def _clear_cache(self):
        """Clear CUDA cache - shared by BaseNeuralModel and LLMTrainer"""
        with torch.no_grad():
            torch.cuda.empty_cache()

    # def __wrap(self, model):
    #     if not isinstance(model, BaseNeuralModel):
    #         return BaseNeuralModel.wrap(model, self.params)
    #     return model

    @staticmethod
    def get_validation_frequency(epoch, lr):
        if epoch < 10:
            return 1  # Validate frequently in early epochs
        elif lr < 0.01:
            return 5  # Validate less frequently after learning rate decay
        else:
            return 2  # Default validation frequency

    @property
    def is_quantised(self):
        return getattr(self, '_is_quantised', False)

    @property
    def optimizer(self) -> torch.optim.Optimizer:
        return self.trainer_objects['optimizer']

    @property
    def scheduler(self):
        return self.trainer_objects['scheduler']


class BaseNeuralForecaster(BaseNeuralModel):
    """Class responsible for NN model implementation.

    Attributes:
        self.num_features: int, the number of features.

    Example:
        Build a Fedot pipeline with a forecasting model node and fit it on
        time-series :class:`~fedot.core.data.data.InputData`.
    """

    def __init__(self, params: Optional[OperationParameters] = None, model: Optional[torch.nn.Module] = None):
        super().__init__(params)
        self.train_horizon = self.params.get('train_horizon', 1)
        self.test_horizon = self.params.get('test_horizon', 1)
        self.in_sample_regime = self.params.get('use_in_sample', True)
        self.use_exog_features = self.params.get('use_exog_features', False)
        self.forecasting_blocks = int(self.test_horizon / self.train_horizon)
        self.loss = self.params.get('loss', 'smape')
        self.val_interval = 5

    def out_of_sample_predict(self, tensor_endogen: Tensor, tensor_exogen: Tensor, target: Tensor):
        pred = self.model(x=tensor_endogen, mask=None)  # output [bs x seq_len x horizon]
        predict = pred[:, -1, :][:, None, :]  # take predict from last point as output [bs x 1 x train_horizon]
        return predict

    def create_features_from_predict(self, tensor_endogen: Tensor, tensor_exogen: Tensor, predict: Tensor):
        features_from_predict = torch.concat([predict, tensor_exogen], dim=1)
        tensor_endogen = tensor_endogen[:, :, self.train_horizon:]
        tensor_endogen = torch.concat([tensor_endogen, features_from_predict], dim=2)
        return tensor_endogen

    def in_sample_predict(self, tensor_endogen: Tensor, tensor_exogen: Tensor, target: Tensor):
        all_predict = []
        new_tensor_endogen = tensor_endogen
        for block in range(self.forecasting_blocks):
            start_idx, end_idx = block * self.train_horizon, block * self.train_horizon + self.train_horizon
            exog_feature = tensor_exogen[:, :, start_idx:end_idx]
            horizon_pred = self.out_of_sample_predict(new_tensor_endogen, exog_feature,
                                                      target)  # output [bs x 1 x train_horizon]
            all_predict.append(horizon_pred)
            new_tensor_endogen = self.create_features_from_predict(new_tensor_endogen, exog_feature, horizon_pred)
        in_sample_predict = torch.concat(all_predict, dim=2)  # output [bs x 1 x test_horizon]
        return in_sample_predict

    def _run_one_epoch(self, epoch, dataloader, loss_fn, optimizer):
        training_loss = 0.0
        self.model.train()
        for batch in dataloader:
            x_hist, x_fut, y = [b.to(self.device) for b in batch]
            predict = self.out_of_sample_predict(x_hist, x_fut, y)
            loss = loss_fn(predict, y)  # output [bs x last_hist_val x train_horizon]
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            training_loss += loss.item()
        return optimizer, loss_fn, training_loss

    def _predict_model(self, input_data: CompressionInputData, output_mode: str = 'default'):
        self.model.eval()

        def predict_loop(batch):
            x_hist, x_fut, y = [b.to(self.device) for b in batch]
            if self.in_sample_regime:
                predict = self.in_sample_predict(x_hist, x_fut, y)
            else:
                predict = self.out_of_sample_predict(x_hist, x_fut, y)
            predict = predict.cpu().detach().numpy().squeeze()
            target = y.cpu().detach().numpy().squeeze()
            return predict, target

        prediction = list(map(lambda batch: predict_loop(batch), input_data.test_dataloader))
        all_prediction = np.concatenate([x[0] for x in prediction])
        # all_target = np.concatenate([x[1] for x in prediction])
        return all_prediction
