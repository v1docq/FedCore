"""
Utilities for quantization operations.

Contains quantization-specific utilities, cleaned from reassembly logic.
"""

from copy import deepcopy
from functools import partial
import inspect
from typing import Callable, Dict, Literal, Optional, Union

import torch
from torch.ao.quantization.quantize import (
    has_no_children_ignoring_parametrizations,
    quantize,
    quantize_dynamic,
    quantize_qat
)
from torch.ao.quantization.qconfig import QConfigAny
from torch.ao.quantization.stubs import QuantStub, DeQuantStub
from torch.ao.quantization.utils import get_qconfig_dtypes
from torch.nn.quantized import FloatFunctional
import torch.nn as nn
import torchvision.models.resnet as resnet

from fedcore.models.network_impl.decomposed_layers import (
    IDecomposed,
    DecomposedLinear,
    DecomposedEmbedding,
    DecomposedConv1d,
    DecomposedConv2d
)
from fedcore.architecture.abstraction.accessor import Accessor
from fedcore.architecture.abstraction.delegator import IDelegator
from fedcore.architecture.computational.devices import extract_device, default_device


__all__ = [
    'QDQWrapper',
    'QDQWrapping',
    'uninplace',
    'reset_qconfig',
    'RecreatedDecomposed',
    'get_flattened_qconfig_dict'
]

QConfigMapping = QConfigAny


def uninplace(model: nn.Module):
    """Convert in-place operations to out-of-place for quantization compatibility."""
    for name, module in model.named_modules():
        if hasattr(module, 'inplace') and module.inplace:
            module.inplace = False


def get_flattened_qconfig_dict(qconfig_mapping: QConfigMapping) -> Dict[Union[Callable, str], QConfigAny]:
    """Flatten global, object-type, and module-name qconfig entries.

    The result is a single mapping compatible with PyTorch's
    ``propagate_qconfig_`` helper. ``module_name_regex`` entries are
    currently ignored.

    Args:
        qconfig_mapping: Nested qconfig mapping with ``""``, ``object_type``,
            and ``module_name`` sections.

    Returns:
        Flat dict mapping module keys and callables to qconfig objects.
    """
    flattened: Dict[Union[Callable, str], QConfigAny] = {"": qconfig_mapping.global_qconfig}
    for obj, qconfig in qconfig_mapping.object_type_qconfigs.items():
        flattened[obj] = qconfig
    for obj, qconfig in qconfig_mapping.module_name_qconfigs.items():
        flattened[obj] = qconfig
    return flattened


def _recreate_embedding(module):
        assert isinstance(module, torch.nn.Embedding)
        new = torch.nn.Embedding(
            module.num_embeddings,
            module.embedding_dim,
            module.padding_idx,
            module.max_norm,
            module.norm_type,
            module.scale_grad_by_freq,
            module.sparse,
            module.weight,
            getattr(module.weight, 'device', default_device()),
            getattr(module.weight, 'dtype', torch.float32)
        )
        new.load_state_dict(module.state_dict())
        return new

def _recreate_linear(module):
    assert isinstance(module, torch.nn.Linear)
    raise NotImplementedError


class RecreatedDecomposed(nn.Sequential):
    __non_redirected = {'forward', '__init__', 'routing', '0', '1'}
    def __init__(self, *args, routing=None):
        super().__init__(*args)
        self.routing = routing or {}

    def __getattr__(self, name):
        if not name in self.__non_redirected:
            name, module = self.routing.get(name, (name, '0'))
            return getattr(super().__getattr__(module), name)
        else:
            return super().__getattr__(name)


# Compatibility imports share the same operator-preserving implementation.
from fedcore.algorithm.low_rank.reassembly.decomposed_recreation import (
    _recreate_decomposed_linear, _recreate_decomposed_embedding,
    _recreate_decomposed_conv2d, _recreate_decomposed_conv1d,
)


class ResidualAddWrapper(nn.Module):
    """Wrapper for ResNet residual blocks to support quantization."""

    def __init__(self, module):
        super().__init__()
        self.module = module
        self.skip_add = FloatFunctional()

        self.qconfig = getattr(module, 'qconfig', None)

    def forward(self, x):
        identity = x
        out = self.module.conv1(x)
        out = self.module.bn1(out)
        out = self.module.relu(out)
        out = self.module.conv2(out)
        out = self.module.bn2(out)

        if self.module.downsample is not None:
            identity = self.module.downsample(x)

        out = self.skip_add.add_relu(out, identity)
        return out


def are_qconfigs_equal(qconfig1, qconfig2) -> bool:
    return get_qconfig_dtypes(qconfig1) == get_qconfig_dtypes(qconfig2)


def reset_qconfig(model: nn.Module, mapping=Dict[nn.Embedding, Optional[QConfigAny]]):
    for m in model.modules():
        t = type(m)
        if t in mapping:
            m.qconfig = mapping[t]
    return model


class QDQWrapper(Accessor):
    """Utility class for quantization operations."""

    __conventional_modules = {cls[1] for cls in inspect.getmembers(torch.nn.modules, inspect.isclass)}

    @classmethod
    def __is_conventional_module(cls, module: nn.Module):
        return type(module) in cls.__conventional_modules

    @classmethod
    def __qconfig_requires_qdq(cls, module):
        qconfig = getattr(module, 'qconfig', None)
        try:
            act_type = get_qconfig_dtypes(qconfig)[0]
        except Exception:
            act_type = None
        return act_type in {torch.quint8, torch.qint8}

    @staticmethod
    def is_leaf_quantizable(module: nn.Module,
                            example_inputs: tuple,
                            mode: Literal['qat', 'static', 'dynamic']):
        if example_inputs[0] is None:
            return False
        module = deepcopy(module)
        module.train(mode == 'qat')
        module.to(default_device())

        def run_fn(model: nn.Module, *example_inputs: tuple):
            model(*example_inputs)

        p_f = {
            'qat': partial(quantize_qat, run_fn=run_fn, run_args=example_inputs),
            'static': partial(quantize, run_fn=run_fn, run_args=example_inputs),
            'dynamic': quantize_dynamic,
        }[mode]

        if (example_inputs and isinstance(example_inputs[0], torch.Tensor) and
                example_inputs[0].dtype not in {torch.int16, torch.int32, torch.int64, torch.int8}):
            m = QDQWrapping(module, 'pre')
        else:
            m = module
        m.qconfig = getattr(module, 'qconfig')

        try:
            qm = p_f(m)
            qm(*example_inputs)
            return True
        except Exception:
            module.qconfig = None
            return False

    @classmethod
    def _replace_dicts(cls, d):
        for name, branch in d._layers.items():
            last_q = None
            for module in branch.modules():
                if isinstance(module, QDQWrapping):
                    if module.mode == 'pre':
                        last_q = module
                    else:
                        last_q = None
            if last_q is None: continue
            del d[name]
            d[name] = QDQWrapping(branch, 'last', last_q.qconfig)

    @classmethod
    def add_quant_entry_exit(cls, m: nn.Module, *example_input, allow: set = None, mode='static'):
        """Add quantization entry/exit points to model."""
        device = default_device()

        example_input = tuple(
            inp.to(device) if hasattr(inp, 'to') else inp for inp in example_input
        )

        with torch.no_grad():
            # Snapshot the tree before replacing modules. Static INT8 operators
            # need quantized inputs; each wrapper restores float outputs for
            # surrounding operations (including residual additions).
            for name, module in list(m.named_modules()):
                if not name or mode == 'dynamic':
                    continue
                if allow and type(module) not in allow:
                    continue

                if cls.__is_conventional_module(module) and not list(module.children()):
                    if cls.__qconfig_requires_qdq(module):
                        wrapped = QDQWrapping(module, 'both')
                        cls.set_module(m, name, wrapped)
        return m


class QDQWrapping(nn.Module, IDelegator):
    """Quantization-Dequantization wrapper for modules."""

    __non_redirect = {'mode', 'base', 'quant', 'dequant', '_order', '_is_rnn', '__h'}

    def __init__(self, base, mode='pre', qconfig=None):
        super().__init__()
        self.mode = mode
        self.base = base
        self._order = {'pre': ['quant', 'base'],
                       'post': ['dequant', 'base'],
                       'both': ['quant', 'base', 'dequant'],
                       'last': ['base', 'dequant']}[mode]
        self.quant = QuantStub(qconfig or getattr(self.base, 'qconfig', None)) if 'quant' in self._order else None
        self.dequant = DeQuantStub(qconfig or getattr(self.base, 'qconfig', None)) if 'dequant' in self._order else None
        if mode == 'post':
            assert qconfig, 'For post mode you need to specify the previous layer\'s qconfig'
        self.qconfig = qconfig or getattr(self.base, 'qconfig', None)
        self._is_rnn = isinstance(self.base, nn.RNNBase)
        self.__h = None

    def __repr__(self):
        d = {
            'pre': f'{self.quant}\n{self.base}',
            'post': f'{self.dequant}\n{self.base}',
            'both': f'{self.quant}\n{self.base}\n{self.dequant}',
            'last': f'{self.base}\nFinal {self.dequant}'
        }
        return d[self.mode]

    def forward(self, x, *args, **kwargs):
        for layer in self._order:
            module = getattr(self, layer)
            if layer == 'base':
                out = module(x, *args, **kwargs)
                if self._is_rnn:
                    x, self.__h = out
                else:
                    x = out
            else:
                x = module(x)
        return x

    def __call__(self, *input, **kwargs):
        result = super().__call__(*input, **kwargs)
        return (result, self.__h) if self._is_rnn else result

    def __getattr__(self, name):
        if name not in self.__non_redirect:
            return getattr(super().__getattr__('base'), name)
        else:
            return super().__getattr__(name)
