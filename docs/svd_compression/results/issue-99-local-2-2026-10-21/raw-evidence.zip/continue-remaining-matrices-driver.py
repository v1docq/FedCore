"""Continue only unstarted sizes after a recorded status-reader interruption."""
from datetime import datetime, timezone
import copy
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import psutil

REPO = Path('C:/Users/user/Documents/Codex/FedCore-SVD-Comparisons-2026-10-13/checkout')
RUN = Path('C:/Users/user/Documents/Codex/FedCore-Issue99-Local-2026-10-20/local2-run-1')
sys.path.insert(0, str(REPO))
from fedcore.experiments import compression_search_local2 as parent
from fedcore.experiments.compression_search_matrix import SIZE_SECONDS

ledger = parent.read_json(RUN/'resource-ledger.json')
original = parent.read_json(RUN/'protocol.json')
previous = parent.read_json(RUN/'matrix-continuation-protocol.json')
assert ledger['status'] == 'stopped' and 'PermissionError' in ledger['stop_reason']
assert ledger['jobs'][-1]['job'] == 'matrix-8' and ledger['jobs'][-1]['status'] == 'succeeded'
for proc in psutil.process_iter(['pid', 'cmdline']):
    try:
        argv = proc.info['cmdline'] or []
        assert not ('--worker' in argv and str(RUN).lower().replace('\\','/') in ' '.join(argv).lower().replace('\\','/')), proc.pid
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        continue
assert parent.count_lines(RUN/'matrix-attempts.jsonl') == 1765
assert parent.count_lines(RUN/'mlp-attempts.jsonl') == 5106
assert not (RUN/'remaining-matrices-protocol.json').exists()
assert all(not (RUN/'jobs'/f'matrix-{n}').exists() for n in (128,512,1024))
stage = next(row for row in ledger['stages'] if row['stage'] == 'matrix')
started, deadline = ledger['started_at'], stage['deadline']
assert started == original['package_started_at'] == 716.9891238
assert stage['started_at'] == 1942.1477145 and deadline == 3742.1477145
assert time.perf_counter() < deadline-120
assert hashlib.sha256(parent.PLAN.read_bytes()).hexdigest() == original['approved_plan_sha256']
assert sorted([d.metadata['Name'], d.version] for d in importlib.metadata.distributions()) == original['environment']['packages']
sources = parent.source_hashes()
changed = {name for name in set(sources)|set(previous['source_files']) if sources.get(name) != previous['source_files'].get(name)}
assert changed == {'fedcore/experiments/compression_search_local2.py'}, changed
shutil.copyfile(RUN/'resource-ledger.json', RUN/'stopped-resource-ledger-2.json')
shutil.copyfile(__file__, RUN/'continue-remaining-matrices-driver.py')
shutil.copyfile(parent.__file__, RUN/'continued-parent-source-2.py')
revision = subprocess.run(['git','rev-parse','HEAD'], cwd=REPO, capture_output=True, text=True, check=True).stdout.strip()
patch = subprocess.run(['git','diff',previous['git_revision'],revision,'--','fedcore'], cwd=REPO, capture_output=True, text=True, check=True).stdout
(RUN/'status-read-fix.patch').write_text(patch, encoding='utf-8')
job = parent.read_json(RUN/'jobs/matrix-32/job.json')
result = parent.read_json(RUN/'jobs/matrix-32/result.json')
assert result['status'] == 'succeeded' and result['completed_streams'] == 107
interrupted = dict(job='matrix-32', kind='matrix', status='monitoring_interrupted', returncode=None,
    stop='parent_status_read_permission_error', error=ledger['stop_reason'],
    result_path=str(RUN/'jobs/matrix-32/result.json'), svd_telemetry=parent._telemetry(RUN/'jobs/matrix-32'),
    resources=dict(started_at=job['worker_started_at'], completed_at=None, elapsed_seconds=None,
        peak_tree_rss_bytes=None, minimum_available_ram_bytes=None, samples=None),
    monitoring_complete=False, child_absence_confirmed_at=time.perf_counter(),
    note='Child result and telemetry completed; original monitor did not record its resource envelope. Timing is diagnostic only.')
assert not (RUN/'jobs/matrix-32/resources.json').exists()
parent.write_json(RUN/'jobs/matrix-32/resources.json', interrupted)
ledger['jobs'].append(interrupted)
stage['jobs'].append('matrix-32')
protocol = copy.deepcopy(original)
protocol.pop('protocol_sha256')
protocol.update(git_revision=revision, source_files=sources,
    source_sha256=hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest(),
    original_protocol_sha256=original['protocol_sha256'], previous_protocol_sha256=previous['protocol_sha256'],
    continuation_recorded_utc=datetime.now(timezone.utc).isoformat(),
    amendment=dict(kind='status_reader_fix_and_only_unstarted_sizes',
        authorization='Existing approved package and one explicitly authorized relocated admission; no further gate or size retry',
        scientific_parameters_changed=False, numerical_functions_changed=False, remaining_sizes=[128,512,1024],
        original_matrix_started_at=stage['started_at'], original_matrix_deadline=deadline,
        original_package_started_at=started, original_package_deadline=started+7200,
        prior_mlp_actions=5106, prior_matrix_requests=1765, predicted_full_matrix_requests=4333,
        unverified_size=32, no_retry_sizes=[8,32], no_admission_retry=True,
        driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
protocol['protocol_sha256'] = hashlib.sha256(json.dumps(protocol, sort_keys=True).encode()).hexdigest()
parent.write_json(RUN/'remaining-matrices-protocol.json', protocol)
record = dict(kind=protocol['amendment']['kind'], started_at=time.perf_counter(),
    protocol_sha256=protocol['protocol_sha256'], source_sha256=protocol['source_sha256'],
    git_revision=revision, previous_stop_reason=ledger['stop_reason'],
    previous_matrix_completed_at=stage.get('completed_at'))
ledger['continuations'].append(record)
ledger['status'] = 'running'
def save():
    ledger.update(elapsed_seconds=time.perf_counter()-started,
        mlp_attempts=parent.count_lines(RUN/'mlp-attempts.jsonl'),
        matrix_attempts=parent.count_lines(RUN/'matrix-attempts.jsonl'))
    parent.write_json(RUN/'resource-ledger.json', ledger)
save()
try:
    new_jobs = []
    for n in (128,512,1024):
        end = min(time.perf_counter()+SIZE_SECONDS[n], deadline-120)
        row = parent.run_job(RUN, dict(job=f'matrix-{n}', kind='matrix', n=n, hard_seconds=SIZE_SECONDS[n]), protocol, started, end)
        ledger['jobs'].append(row)
        stage['jobs'].append(row['job'])
        new_jobs.append(row)
        save()
        print(json.dumps(dict(job=row['job'], status=row['status'], elapsed=ledger['elapsed_seconds'], matrix=ledger['matrix_attempts'])), flush=True)
        if row['status'] == 'failed':
            raise RuntimeError(row)
    ledger['status'] = 'partial'  # Size32 monitoring was interrupted, even if all other jobs completed.
    ledger['stop_reason'] = 'Size32 resource monitoring incomplete; its timings remain diagnostic, without rerun'
except BaseException as error:
    ledger.update(status='stopped', stop_reason=f'{type(error).__name__}: {error}')
    raise
finally:
    stage['completed_at'] = record['completed_at'] = time.perf_counter()
    save()
print(json.dumps(dict(status=ledger['status'], elapsed=ledger['elapsed_seconds'], mlp=ledger['mlp_attempts'], matrix=ledger['matrix_attempts'])), flush=True)
