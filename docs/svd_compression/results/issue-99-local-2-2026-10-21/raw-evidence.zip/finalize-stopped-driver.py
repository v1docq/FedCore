"""Complete only the already approved independent test stage after status-I/O stop."""
import copy
import json
from pathlib import Path
import shutil
import sys
import time

REPO = Path('C:/Users/user/Documents/Codex/FedCore-SVD-Comparisons-2026-10-13/checkout')
RUN = Path('C:/Users/user/Documents/Codex/FedCore-Issue99-Local-2026-10-20/local2-run-1')
sys.path.insert(0, str(REPO))
from fedcore.experiments import compression_search_local2 as parent

ledger = parent.read_json(RUN/'resource-ledger.json')
protocol = parent.read_json(RUN/'protocol.json')
assert ledger['status'] == 'stopped'
assert 'PermissionError' in ledger['stop_reason'] and ledger['jobs'][-1]['job'] == 'matrix-admission'
assert sum(row['kind'] == 'search' and row['status'] == 'succeeded' for row in ledger['jobs']) == 54
assert sum(row['kind'] == 'oracle' and row['status'] == 'succeeded' for row in ledger['jobs']) == 3
assert not (RUN/'stopped-resource-ledger-1.json').exists()
assert parent.source_hashes() == protocol['source_files']
shutil.copyfile(RUN/'resource-ledger.json', RUN/'stopped-resource-ledger-1.json')
shutil.copyfile(__file__, RUN/'finalize-stopped-driver.py')
original = copy.deepcopy(ledger)
started = ledger['started_at']
now = time.perf_counter()
assert now < started + 6900
selection_hash = parent.freeze_selections(RUN)
ledger['selections_sha256'] = selection_hash
ledger['continuations'] = [dict(kind='approved-independent-finalize-after-status-io-stop',
    started_at=now, original_started_at=started, original_stop_reason=original['stop_reason'],
    source_sha256=protocol['source_sha256'], no_matrix_retry=True)]
stage = dict(stage='finalize', started_at=now, deadline=min(now+300, started+7200), jobs=[])
ledger['stages'].append(stage)
ledger['status'] = 'running'
def save():
    ledger.update(elapsed_seconds=time.perf_counter()-started,
        mlp_attempts=parent.count_lines(RUN/'mlp-attempts.jsonl'),
        matrix_attempts=parent.count_lines(RUN/'matrix-attempts.jsonl'))
    parent.write_json(RUN/'resource-ledger.json', ledger)
save()
try:
    for seed in parent.SPLITS:
        row = parent.run_job(RUN, dict(job=f'finalize-{seed}', kind='finalize',
            split_seed=seed, model_seed=seed, selections_sha256=selection_hash, hard_seconds=100),
            protocol, started, stage['deadline'])
        ledger['jobs'].append(row)
        stage['jobs'].append(row['job'])
        save()
        print(json.dumps(dict(job=row['job'], status=row['status'], mlp=ledger['mlp_attempts'])), flush=True)
        if row['status'] == 'failed':
            raise RuntimeError(row)
    ledger['status'] = 'partial'
finally:
    stage['completed_at'] = time.perf_counter()
    save()
print(json.dumps(dict(status=ledger['status'], elapsed=ledger['elapsed_seconds'],
    mlp=ledger['mlp_attempts'], matrix=ledger['matrix_attempts'])), flush=True)
