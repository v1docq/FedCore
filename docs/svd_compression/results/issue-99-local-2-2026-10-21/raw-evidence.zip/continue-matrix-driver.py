"""One explicitly authorized matrix-admission retry with unchanged outer clocks."""
from datetime import datetime, timezone
import copy
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

REPO = Path('C:/Users/user/Documents/Codex/FedCore-SVD-Comparisons-2026-10-13/checkout')
RUN = Path('C:/Users/user/Documents/Codex/FedCore-Issue99-Local-2026-10-20/local2-run-1')
sys.path.insert(0, str(REPO))
from fedcore.experiments import compression_search_local2 as parent
from fedcore.experiments.compression_search_matrix import SIZES, SIZE_SECONDS

ledger = parent.read_json(RUN/'resource-ledger.json')
original = parent.read_json(RUN/'protocol.json')
assert ledger['status'] == 'partial' and ledger['mlp_attempts'] == 5106 and ledger['matrix_attempts'] == 18
assert all(row['returncode'] is not None for row in ledger['jobs'])
assert all(any(row['job'] == f'finalize-{seed}' and row['status'] == 'succeeded' for row in ledger['jobs']) for seed in parent.SPLITS)
stage = next(row for row in ledger['stages'] if row['stage'] == 'matrix')
assert stage['started_at'] == 1942.1477145 and stage['deadline'] == 3742.1477145
started, matrix_deadline = ledger['started_at'], stage['deadline']
assert started == original['package_started_at'] == 716.9891238
assert time.perf_counter() < min(matrix_deadline-120, started+6900)
assert hashlib.sha256(parent.PLAN.read_bytes()).hexdigest() == original['approved_plan_sha256']
assert sorted([dist.metadata['Name'], dist.version] for dist in importlib.metadata.distributions()) == original['environment']['packages']
sources = parent.source_hashes()
changed = {name for name in set(sources) | set(original['source_files']) if sources.get(name) != original['source_files'].get(name)}
assert changed == {'fedcore/experiments/compression_search_local2.py'}, changed
assert not (RUN/'matrix-continuation-protocol.json').exists(), 'Only one authorized retry'
assert not (RUN/'stopped-matrix-sources-1').exists()
snapshot = RUN/'stopped-matrix-sources-1'
assert snapshot.resolve().parent == RUN.resolve() and (RUN/'matrix-sources').resolve().parent == RUN.resolve()
shutil.copyfile(RUN/'resource-ledger.json', RUN/'resource-ledger-before-matrix-continuation.json')
(RUN/'matrix-sources').rename(snapshot)
shutil.copyfile(__file__, RUN/'continue-matrix-driver.py')
shutil.copyfile(parent.__file__, RUN/'continued-parent-source.py')
revision = subprocess.run(['git','rev-parse','HEAD'], cwd=REPO, capture_output=True, text=True, check=True).stdout.strip()
patch = subprocess.run(['git','diff',original['git_revision'],revision,'--','fedcore'], cwd=REPO, capture_output=True, text=True, check=True).stdout
(RUN/'status-io-fix.patch').write_text(patch, encoding='utf-8')
protocol = copy.deepcopy(original)
protocol.pop('protocol_sha256')
protocol.update(git_revision=revision, source_files=sources,
    source_sha256=hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest(),
    original_protocol_sha256=original['protocol_sha256'], continuation_recorded_utc=datetime.now(timezone.utc).isoformat(),
    amendment=dict(kind='one_relocated_matrix_admission_after_status_io_failure',
        authorization='User explicitly authorized one admission retry within the original outer limits on 2026-10-21',
        scientific_parameters_changed=False, numerical_functions_changed=False,
        original_matrix_started_at=stage['started_at'], original_matrix_deadline=matrix_deadline,
        original_package_started_at=started, original_package_deadline=started+7200,
        original_admission_deadline=stage['started_at']+180,
        relocated_admission_max_seconds=180, prior_mlp_actions=5106, prior_matrix_requests=18,
        prior_svd_starts=13, predicted_full_matrix_requests=4333,
        driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
protocol['protocol_sha256'] = hashlib.sha256(json.dumps(protocol, sort_keys=True).encode()).hexdigest()
parent.write_json(RUN/'matrix-continuation-protocol.json', protocol)
record = dict(kind=protocol['amendment']['kind'], started_at=time.perf_counter(),
    original_started_at=started, original_matrix_deadline=matrix_deadline,
    protocol_sha256=protocol['protocol_sha256'], source_sha256=protocol['source_sha256'], git_revision=revision)
ledger['continuations'].append(record)
ledger['historical_stop_reason'] = ledger['stop_reason']
ledger['status'] = 'running'
def save():
    ledger.update(elapsed_seconds=time.perf_counter()-started,
        mlp_attempts=parent.count_lines(RUN/'mlp-attempts.jsonl'),
        matrix_attempts=parent.count_lines(RUN/'matrix-attempts.jsonl'))
    parent.write_json(RUN/'resource-ledger.json', ledger)
save()
try:
    new_jobs = []
    gate = parent.run_job(RUN, dict(job='matrix-admission-recovery-1', kind='matrix_admission', hard_seconds=180),
        protocol, started, min(time.perf_counter()+180, matrix_deadline-120))
    ledger['jobs'].append(gate)
    stage['jobs'].append(gate['job'])
    new_jobs.append(gate)
    save()
    print(json.dumps(dict(job=gate['job'], status=gate['status'], matrix=ledger['matrix_attempts'])), flush=True)
    if gate['status'] != 'succeeded':
        raise RuntimeError('The single authorized admission retry did not succeed')
    for n in SIZES:
        end = min(time.perf_counter()+SIZE_SECONDS[n], matrix_deadline-120)
        row = parent.run_job(RUN, dict(job=f'matrix-{n}', kind='matrix', n=n, hard_seconds=SIZE_SECONDS[n]),
            protocol, started, end)
        ledger['jobs'].append(row)
        stage['jobs'].append(row['job'])
        new_jobs.append(row)
        save()
        print(json.dumps(dict(job=row['job'], status=row['status'], elapsed=ledger['elapsed_seconds'],
            matrix=ledger['matrix_attempts'])), flush=True)
        if row['status'] == 'failed':
            raise RuntimeError(row)
    ledger['status'] = 'completed_after_io_recovery' if all(row['status'] == 'succeeded' for row in new_jobs) else 'partial'
    ledger['stop_reason'] = None if ledger['status'] == 'completed_after_io_recovery' else 'Original matrix stage deadline reached'
except BaseException as error:
    ledger.update(status='stopped', stop_reason=f'{type(error).__name__}: {error}')
    raise
finally:
    stage['completed_at'] = record['completed_at'] = time.perf_counter()
    save()
print(json.dumps(dict(status=ledger['status'], elapsed=ledger['elapsed_seconds'],
    mlp=ledger['mlp_attempts'], matrix=ledger['matrix_attempts'])), flush=True)
