import torch
import pandas as pd
from functools import wraps

from typing import Optional

from fedot.core.composer.metrics import Metric
from fedot.core.composer.metrics import (ComplexityMetric, ComputationTime, NodeNum, QualityMetric,
                                         StructuralComplexity)

import torch
from torch import Tensor
from abc import ABC, abstractmethod
from typing import List, Dict, Union
import torchmetrics


# Import necessary libraries

from importlib import import_module

from fedcore.data.data import CompressionOutputData
from fedcore.repository.constant_repository import FedotTaskEnum
from fedcore.api.utils.misc import camel_to_snake
from fedcore.tools.ruler import PerformanceEvaluator


from fedcore.api.utils.misc import cuda_transfer

# ============================== Pareto =====================================


from fedcore.metrics.pareto import ParetoMetrics

class QualityMetric(Metric):
    """Base metric computed via pipeline.predict()."""
    default_value = 0
    need_to_minimize = False
    output_mode = "raw"  # 'labels' | 'probs' | 'raw' | 'compress'
    split = "val"             # 'val' | 'test'

    @classmethod
    def get_value(cls, pipeline, reference_data, validation_blocks=None) -> float:
        """Compute metric on features.<split> using pipeline.predict(output_mode)."""
        results = pipeline.predict(reference_data, output_mode=cls.output_mode)
        prediction = results.predict
        target = getattr(results, 'target', None)
        if isinstance(prediction, CompressionOutputData):
            paired_target = getattr(prediction, 'target', None)
            if paired_target is not None:
                target = paired_target
            prediction = prediction.predict
        if target is None:
            raise ValueError('Metric prediction must include targets from the same labeled pass')
        prediction = torch.as_tensor(prediction).detach().cpu()
        target = torch.as_tensor(target).detach().cpu()
        if len(target) != len(prediction):
            raise ValueError('Prediction and paired targets have different lengths')

        result = cls.metric(target=target, predict=prediction)
        assert result is not None, f"{cls.__name__}.metric() returned None"
        return float(result)

    @staticmethod
    def _get_least_frequent_val(array: torch.Tensor):
        """Return least frequent value in array."""
        unique_vals, count = torch.unique(array, return_counts=True)
        return unique_vals[torch.argmin(count)]

PROBLEM_MAPPING = {
    'ts_forecasting': 'regression',
    'question_answering': 'classification',
    'summarization': 'classification'
}

ATTRIBUTE_MAPPING = {
    'higher_is_better': 'need_to_minimize',
    'is_differentiable': 'is_differentiable'
}

LOADED_METRICS = {}

__problems = [PROBLEM_MAPPING.get(problem.name, problem.name) for problem in FedotTaskEnum]
__problem_to_metric = {
    problem: getattr(torchmetrics, problem).__all__ for problem in __problems
}
_METRICS_TO_PROBLEM = {
    metric: problem for problem, metrics in __problem_to_metric.items() for metric in metrics
}


def get_available_metrics(problem):
    module = import_module(f'torchmetrics.{PROBLEM_MAPPING.get(problem, problem)}')
    return module.__all__


def _problem_based_output_convertor(problem):
    def output_convertor(metric):
        wraps(metric)
        def _wrapped_output(cls, target, predict, **metric_kw):
            if problem is not None:
                if isinstance(predict, CompressionOutputData):
                    predict = predict.predict
                assert isinstance(target, torch.Tensor) and isinstance(predict, torch.Tensor), f'Current types are: {type(target)} and {type(predict)}'
            try:
                return metric(cls, target, predict, **metric_kw)
            except (ValueError):
                if problem == 'classification':
                    predict = torch.argmax(predict, -1)
                return metric(cls, target, predict, **metric_kw)
        return _wrapped_output
    return output_convertor

FEDOT_STRUCTURAL = {
    'structural': StructuralComplexity,
    'node_number': NodeNum,
    'computation_time': ComputationTime
}

# executor, unit, optimization direction. Legacy PowerConsumption means energy.
COMPUTATIONAL_METRICS = {
    'Latency': ('measure_latency', 'ms/batch', True),
    'Throughput': ('measure_throughput', 'samples/s', False),
    'ModelSize': ('measure_model_size', 'MiB (serialized state)', True),
    'Power': ('measure_power', 'W', True),
    'PowerConsumption': ('measure_energy', 'J/batch', True),
    'Energy': ('measure_energy', 'J/batch', True),
    'EnergyConsumption': ('measure_energy', 'J/batch', True),
}
_NEED_TO_MINIMIZE = {name: spec[2] for name, spec in COMPUTATIONAL_METRICS.items()}
_NEED_TO_MINIMIZE.update({'bleu': False, 'rouge': False, 'meteor': False})

_TEXT_GENERATION_METRICS = {'bleu', 'rouge', 'meteor'}

class MetricFactory:
    __approaches = ['get_fedot', 'get_legacy', 'get_torchmetrics', 'get_computational', 'get_evaluate']
    __cpu_prefix = 'CPU'

    @classmethod
    def get_metric(cls, metric_name, problem=None) -> QualityMetric:
        for approach in cls.__approaches:
            try:
                method = getattr(cls, approach)
                metric = method(metric_name, problem)
                return metric
            except (KeyError, ModuleNotFoundError, AttributeError):
                pass
        raise NameError('Unknown metric name')

    @classmethod
    def get_fedot(cls, metric_name, problem=None) -> QualityMetric:
        return FEDOT_STRUCTURAL[metric_name]

    @classmethod
    def get_legacy(cls, metric_name, problem=None):
        if not metric_name.startswith('Legacy'):
            raise KeyError(metric_name)
        from fedcore.metrics import cv_metrics
        name = metric_name[len('Legacy'):]
        allowed = ('Accuracy','Precision','F1','MASE','MAPE','R2','MSE','MAE','SMAPE','MSLE')
        if name not in allowed:
            raise KeyError(metric_name)
        return getattr(cv_metrics, name)

    @classmethod
    def get_torchmetrics(cls, metric_name, problem=None) -> QualityMetric:
        if metric_name in LOADED_METRICS:
            return LOADED_METRICS[metric_name]

        original_name = metric_name
        # get suffix of class number
        metric_name = metric_name.split('__')
        if len(metric_name) < 2:
            suffix = None
        else:
            suffix = int(metric_name[-1])
        metric_name = metric_name[0]

        if problem is None:
            problem = _METRICS_TO_PROBLEM.get(metric_name)

        module = import_module(f'torchmetrics.{PROBLEM_MAPPING.get(problem, problem)}')
        parent_cls = getattr(module, metric_name)
        attributes = {
            child_attr: getattr(parent_cls, parent_attr) for parent_attr, child_attr in ATTRIBUTE_MAPPING.items()
        }
        attributes['problem'] = problem

        # special cases
        attributes['need_to_minimize'] = not attributes['need_to_minimize']

        @classmethod
        @_problem_based_output_convertor(problem)
        def metric(cls: torchmetrics.Metric, target, predict, **metric_kw) -> torch.Tensor:
            """
            Compute metric value
            Args:
                target: torch.Tensor
                predict: torch.Tensor
                **metric_kw - any to instantiate torchmetrics' metric
            """
            if suffix and problem == 'classification':
                metric_kw['num_classes'] = suffix
            instance = cls(**metric_kw)
            #print('@@@~', predict.size())
            instance.update(predict.cpu(), target.cpu())
            result = instance.compute()
            del instance
            return result

        attributes['metric'] = metric
        new_metric = type(
            original_name, (parent_cls, QualityMetric), attributes
        )
        LOADED_METRICS[original_name] = new_metric
        return new_metric

    @classmethod
    def get_computational(cls, metric_name: str, model_regime: str = 'model_after') -> QualityMetric:
        if metric_name in LOADED_METRICS:
            return LOADED_METRICS[metric_name]

        is_cpu = metric_name.upper().startswith(cls.__cpu_prefix)
        true_metric_name = metric_name[len(cls.__cpu_prefix):] if is_cpu else metric_name
        method_name, unit, need_minimize = COMPUTATIONAL_METRICS[true_metric_name]
        if not hasattr(PerformanceEvaluator, method_name):
            raise AttributeError(f"PerformanceEvaluator has no method '{method_name}'")

        @classmethod
        def get_value(cls, pipeline, reference_data, validation_blocks=None) -> float:
            from fedcore.data.data import CompressionInputData
            if isinstance(reference_data, CompressionInputData):
                reference_data = reference_data.train_dataloader
            assert isinstance(reference_data, torch.utils.data.DataLoader), f'{type(reference_data)}'
            pe = PerformanceEvaluator(pipeline, data=reference_data, model_regime=model_regime)
            metric = getattr(pe, method_name)(
                device=torch.device('cpu') if is_cpu or not torch.cuda.is_available() else torch.device('cuda')
            )
            if isinstance(metric, tuple):
                return float(metric[0])
            return float(metric)

        @classmethod
        def metric(cls: torchmetrics.Metric, target, predict, **metric_kw) -> torch.Tensor:
            raise NotImplementedError(f'The call for `metric` method for {metric_name} is not supported. Use `get_value` instead')

        new_metric = type(
            metric_name, (QualityMetric,), {
                'get_value': get_value,
                'need_to_minimize': need_minimize,
                'default_value': float('inf') if need_minimize else 0.,
                'unit': unit,
                'executor': method_name,
                'metric': metric
            }
        )
        LOADED_METRICS[metric_name] = new_metric
        return new_metric

    @classmethod
    def get_evaluate(cls, metric_name, problem=None) -> QualityMetric:
        """
        Get evaluate metric using EvaluateMetric from nlp_metrics.py.
        This avoids duplication and ensures proper output_mode handling.
        """
        if metric_name in LOADED_METRICS:
            return LOADED_METRICS[metric_name]

        from fedcore.metrics.nlp_metrics import EvaluateMetric
        if metric_name.lower() not in _TEXT_GENERATION_METRICS:
            raise KeyError(metric_name)
        original_name = metric_name

        if problem is None:
            problem = _METRICS_TO_PROBLEM.get(metric_name)

        metric_name_lower = metric_name.lower()
        if metric_name_lower in _TEXT_GENERATION_METRICS:
            output_mode = "texts"
        else:
            output_mode = "labels"

        need_minimize = _NEED_TO_MINIMIZE.get(metric_name, _NEED_TO_MINIMIZE.get(metric_name.upper(), False))

        new_metric = type(
            original_name, (EvaluateMetric,), {
                'metric_name': metric_name,
                'problem': problem,
                'need_to_minimize': need_minimize,
                'output_mode': output_mode,
            }
        )
        LOADED_METRICS[original_name] = new_metric
        return new_metric


def calculate_metrics(
    metric_names: tuple[str, ...],
    target: torch.Tensor,
    predict: torch.Tensor,
    rounding_order: int = 3,
    ):
    values = {metric_name: float(MetricFactory.get_metric(metric_name).metric(target, predict)) for metric_name in metric_names}
    return _to_df(values, rounding_order)

# -------------------- Utility Function: Convert to DataFrame --------------------

def _to_df(values: dict, rounding: int = 3) -> pd.DataFrame:
    """
    Convert a dictionary of metric values into a DataFrame with one row.

    Args:
        values (dict): A dictionary of metric names and values.
        rounding (int): The number of decimal places to round the metric values.

    Returns:
        pd.DataFrame: A DataFrame with one row of rounded metric values.
    """
    return pd.DataFrame(values, index=[0]).round(rounding)


# -------------------- General Metric Calculation Function --------------------

# def calculate_regression_metrics(
#     target: torch.Tensor,
#     predict: torch.Tensor,
#     rounding_order: int = 3,
#     metric_names: tuple[str, ...] = ("r2", "rmse", "mae"),
#     is_forecasting: bool = False
# ) -> pd.DataFrame:
#     """
#     Compute metrics for regression or forecasting (time series) tasks.

#     Args:
#         target (torch.Tensor): Ground truth values.
#         predict (torch.Tensor): Predicted values.
#         rounding_order (int): Decimal places for rounding the results.
#         metric_names (tuple): Metrics to compute.
#         is_forecasting (bool): Flag to indicate if it is forecasting or not.

#     Returns:
#         pd.DataFrame: A DataFrame containing the computed metrics.
#     """

#     values = {name: calculate_metrics(target, predict, name) for name in metric_names if name in REGRESSION_METRICS}

#     return _to_df(values, rounding_order)

# # -------------------- Classification Metrics Calculation --------------------

# def calculate_classification_metrics(
#     target: torch.Tensor,
#     labels: torch.Tensor,
#     probs: Optional[torch.Tensor] = None,
#     rounding_order: int = 3,
#     metric_names: tuple[str, ...] = ("f1", "accuracy")
# ) -> pd.DataFrame:
#     """
#     Compute classification metrics such as Accuracy, F1, Logloss, etc.

#     Args:
#         target (torch.Tensor): Ground truth labels.
#         labels (torch.Tensor): Predicted labels.
#         probs (torch.Tensor, optional): Predicted probabilities (needed for logloss and ROC AUC).
#         rounding_order (int): Decimal places for rounding the results.
#         metric_names (tuple): Metrics to compute.

#     Returns:
#         pd.DataFrame: A DataFrame containing the computed metrics.
#     """
#     values = {}
#     for name in metric_names:
#         metric = CLASSIFICATION_METRICS[name]
#         if name in ("logloss", "roc_auc"):
#             if probs is None:
#                 raise ValueError(f"{name} requires `probs` argument.")
#             values[name] = metric(target, probs)
#         else:
#             values[name] = metric(target, labels)

#     return _to_df(values, rounding_order)

# # -------------------- Computational Metrics Calculation --------------------

# def calculate_computational_metrics(model, dataset, model_regime: str) -> float:
#     """
#     Compute computational metrics like latency and throughput.

#     Args:
#         model (torch.nn.Module): The model to evaluate.
#         dataset: The dataset to evaluate on.
#         model_regime (str): The regime of the model.

#     Returns:
#         float: The computed computational metric (e.g., throughput or latency).
#     """

#     ###################### TODO Here should be called the fedcore.tools.ruler.PerformanceEvaluator
#     pass
