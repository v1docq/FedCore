# FedCore model exporter Docker demo

Данный пример демонстрирует запуск вспомогательного сервиса экспорта моделей через Docker-контейнер.

## Назначение

Пример показывает:

1. запуск API-сервиса экспорта модели;
2. проверку состояния сервиса через `/health`;
3. загрузку модельного артефакта через `/upload`;
4. имитацию экспорта модели через `/export`;
5. получение списка загруженных и экспортированных файлов через `/files`.

## Как запустить

Из корня репозитория:

```bash
cd deployment/model_exporter
docker compose up --build
```

После запуска сервис будет доступен по адресу:

```text
http://localhost:5000
```

## Проверка состояния сервиса

```bash
curl http://localhost:5000/health
```

Ожидаемый ответ:

```json
{
  "status": "ok",
  "service": "fedcore-model-exporter-demo"
}
```

## Загрузка файла

```bash
curl -X POST "http://localhost:5000/upload" \
  -F "file=@demo_model.pt"
```

## Экспорт файла

```bash
curl -X POST "http://localhost:5000/export?filename=demo_model.pt&target_format=onnx"
```

## Получение списка файлов

```bash
curl http://localhost:5000/files
```

## Важное замечание

В данном demo-примере эндпоинт `/export` выполняет имитацию экспорта: копирует загруженный файл и меняет расширение на целевой формат.

В промышленной версии в этот блок может быть подключен реальный pipeline FedCore для экспорта моделей в ONNX, TensorRT, TFLite / LiteRT, OpenVINO или другие форматы.
