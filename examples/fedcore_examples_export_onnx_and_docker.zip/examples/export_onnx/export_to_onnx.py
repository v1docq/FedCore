"""
ResNet-18 export to ONNX demo.

This script is a standalone version of the notebook example.
It creates a small ResNet-18 model, exports it to ONNX and writes an export report.

Minimal dependencies:
    pip install torch pandas onnx
"""

from pathlib import Path
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd

try:
    import onnx
except ImportError as exc:
    raise ImportError(
        "Package 'onnx' is required for this example. Install it with: pip install onnx"
    ) from exc


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super().__init__()

        self.conv1 = nn.Conv2d(in_planes, planes, 3, stride, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, planes, 1, stride, bias=False),
                nn.BatchNorm2d(planes),
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = out + self.shortcut(x)
        return F.relu(out)


class ResNet(nn.Module):
    def __init__(self, block, num_blocks, num_classes=10):
        super().__init__()

        self.in_planes = 64

        self.conv1 = nn.Conv2d(3, 64, 3, 1, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)

        self.layer1 = self._make_layer(block, 64, num_blocks[0], 1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], 2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], 2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], 2)

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_classes)

    def _make_layer(self, block, planes, num_blocks, stride):
        layers = []
        strides = [stride] + [1] * (num_blocks - 1)

        for current_stride in strides:
            layers.append(block(self.in_planes, planes, current_stride))
            self.in_planes = planes * block.expansion

        return nn.Sequential(*layers)

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)

        out = self.avgpool(out)
        out = torch.flatten(out, 1)
        return self.fc(out)


def resnet18(num_classes=10):
    return ResNet(BasicBlock, [2, 2, 2, 2], num_classes=num_classes)


def get_file_size_mb(path):
    return os.path.getsize(path) / (1024 ** 2)


def main():
    results_dir = Path("results/export_onnx")
    results_dir.mkdir(parents=True, exist_ok=True)

    model = resnet18(num_classes=10)
    model.eval()

    dummy_input = torch.randn(1, 3, 32, 32)

    pt_path = results_dir / "resnet18_demo_state_dict.pt"
    onnx_path = results_dir / "resnet18_demo.onnx"

    torch.save(model.state_dict(), pt_path)

    torch.onnx.export(
        model,
        dummy_input,
        onnx_path,
        export_params=True,
        opset_version=17,
        do_constant_folding=True,
        input_names=["input"],
        output_names=["logits"],
        dynamic_axes={
            "input": {0: "batch_size"},
            "logits": {0: "batch_size"},
        },
        dynamo=False,
    )

    onnx_model = onnx.load(str(onnx_path))
    onnx.checker.check_model(onnx_model)

    with torch.no_grad():
        output = model(dummy_input)

    export_report = pd.DataFrame(
        [
            {
                "artifact": "PyTorch state_dict",
                "path": str(pt_path),
                "size_mb": get_file_size_mb(pt_path),
                "status": "saved",
            },
            {
                "artifact": "ONNX model",
                "path": str(onnx_path),
                "size_mb": get_file_size_mb(onnx_path),
                "status": "validated",
            },
        ]
    )
    export_report.to_csv(results_dir / "export_report.csv", index=False)

    print(export_report)
    print("ONNX validation status: passed")
    print(f"Input shape: {tuple(dummy_input.shape)}")
    print(f"Output shape: {tuple(output.shape)}")


if __name__ == "__main__":
    main()
