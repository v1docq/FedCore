# ResNet-18 export to ONNX demo

Данный пример демонстрирует экспорт модели ResNet-18 в формат ONNX.

## Назначение

Пример показывает:

1. создание модели ResNet-18;
2. сохранение PyTorch `state_dict`;
3. экспорт модели в формат `.onnx`;
4. проверку корректности ONNX-модели через `onnx.checker`;
5. сохранение отчёта об экспортированных артефактах.

## Как запустить скрипт

Из корня репозитория:

```bash
cd examples/export_onnx
python export_to_onnx.py
```

## Как открыть ноутбук

```bash
jupyter notebook examples/export_onnx/resnet18_export_onnx_demo.ipynb
```

или:

```bash
jupyter lab examples/export_onnx/resnet18_export_onnx_demo.ipynb
```

## Минимальные зависимости

```bash
pip install torch pandas matplotlib notebook onnx
```

## Ожидаемый результат

После выполнения будут сформированы:

```text
results/export_onnx/resnet18_demo_state_dict.pt
results/export_onnx/resnet18_demo.onnx
results/export_onnx/export_report.csv
```

Ноутбук и скрипт являются демонстрационным smoke-тестом. Для полноценного эксперимента можно заменить модель на предварительно обученную или сжатую модель FedCore.
